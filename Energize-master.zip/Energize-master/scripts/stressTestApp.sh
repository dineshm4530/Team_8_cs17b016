#!/bin/bash
/Applications/AndroidSDK/platform-tools/adb shell monkey -p com.halcyonwaves.apps.energize -v 1000 -s 0
