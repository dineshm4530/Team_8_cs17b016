#!/usr/bin/env bash
adb shell am broadcast -a android.intent.action.BOOT_COMPLETED
